# Lynk Audio FX (`lynk_viperfx`)

Module Magisk đưa ViPER4Android lên HU Lynk (IHU732P, Android 9, HAL hiệu ứng âm thanh kiểu cũ). Thay cho
**ViperFix v46** (`extendeddsp`) đang cài qua Scorohub.

## Thành phần và nguồn

| Thành phần | Nguồn | Giấy phép |
|---|---|---|
| Driver `libv4a_re.so` (arm, arm64) | [likelikeslike/ViPERFX_RE](https://github.com/likelikeslike/ViPERFX_RE) (fork của [AndroidAudioMods/ViPERFX_RE](https://github.com/AndroidAudioMods/ViPERFX_RE)), commit `32587b1` (v2.1.1) + [ViPERDSP](https://github.com/likelikeslike/ViPERDSP) `6fc1f1b` (submodule). **Dựng lại từ mã nguồn** trên CI | Script module: GPLv2 (file `LICENSE`). DSP: dịch ngược từ `libv4a_fx.so` gốc, repo không ghi giấy phép, tác giả ghi "không dùng thương mại" |
| App ViPER4Android 2.1.1 (`com.llsl.viper4android`) | [likelikeslike/ViPER4Android](https://github.com/likelikeslike/ViPER4Android), bản phát hành gốc (sha256 `b60a8e38…2cba`) | GPL-3.0 |
| Script cài đặt | MMT Extended (Zackptg5) qua ViPERFX_RE, sửa cho HU | GPLv2 |

Credit: pittvandewitt, MrWhite214, Zackptg5, Martmists, Iscle (ViPER4Android RE / ViPERFX_RE), llsl (ViPERFX_RE v2,
ViPERDSP, app ViPER4Android 2.x), ViPER520 / zhuhang (ViPER4Android FX gốc).

## Khác ViperFix

- **Không có** `liblunaris_viper_masterproxy.so` (thư viện proxy đóng của Lunaris) và **không có** `lunaris_afpatcher_*`
  (vá RAM `libaudioflinger` của audioserver lúc chạy, "ViperKeepActive"). Cả hai là mã đóng, không dùng lại.
- App là ViPER4Android 2.1.1 của llsl (mã nguồn mở), không phải app ViperFX RE của WSTxda (đóng, đã ngừng phát triển).
  Cài đặt và preset trong app cũ không chuyển sang.
- Không chép sẵn 500 file DDC. App mới tải hoặc nạp DDC/IRS từ bộ nhớ.
- Không có các vòng lặp mỗi giây của ViperFix (đọc prefs của app, setprop `persist.mark99.*`, theo dõi logcat sau cuộc gọi
  BT).
- Khi cài: tự tắt `extendeddsp` (tạo cờ `disable`) và bỏ các dòng `v4a_gx` của nó khỏi `audio_effects.*`.

## Phải thử trên xe

1. **Hiệu ứng có giữ được không.** ViperFix vá RAM audioserver để hiệu ứng toàn cục không bị tắt trên đường âm thanh
   ECARX/MTK. Bản này không vá. Cần thử: bật ViPER (Global mode), phát Spotify/YouTube Music, đổi nguồn, dừng/phát lại,
   chờ màn hình tắt rồi bật. Nếu hiệu ứng mất, tìm cách sửa riêng sau (không dùng lại bản vá đóng).
2. **Sau cuộc gọi Bluetooth.** ViperFix khởi động lại service ViPER khi chế độ âm thanh từ HFP về bình thường. Kiểm tra
   hiệu ứng còn chạy sau một cuộc gọi.
3. Hub Spotify phát bằng AudioTrack riêng: chỉ được xử lý ở Global mode.

## Cài

1. Sao lưu module trong Hub.
2. Cài zip này (Hub → Module, hoặc Magisk). Module tự tắt ViperFix.
3. Khởi động lại. Mở app ViPER4Android, bật Global mode.
4. Muốn quay lại ViperFix: tắt `lynk_viperfx`, bật lại `extendeddsp`, khởi động lại.

## Dựng

CI: workflow `Lynk Audio FX module` (`.github/workflows/lynk-audiofx.yml`) chạy trên runner GitHub, ghim commit
ViPERFX_RE và sha256 của app, xuất artifact `lynk-audiofx`. Dựng tay:

```bash
ANDROID_NDK_HOME=... modules/lynk-audiofx/build.sh <ViPERFX_RE có submodule> <ViPER4Android-2.1.1.apk>
```
