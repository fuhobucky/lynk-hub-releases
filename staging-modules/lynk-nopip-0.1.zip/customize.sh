#!/system/bin/sh
# Thay permissions_service.sh bang Magisk overlay; khong ghi vao phan vung /system that.
# Ban trong module giong het ban goc, chi doi "PICTURE_IN_PICTURE allow" thanh "ignore".

ORIG_SHA256=2a935fc7104ff13939fa40cb4032b52817eea0f1777108a0a5620b24136f43fd
TARGET=/system/bin/permissions_service.sh

ui_print " "
ui_print "- Kiem tra thiet bi"

DEV=$(getprop ro.product.device)
if [ "$DEV" != "IHU732P" ]; then
  ui_print "! Module nay chi danh cho dau may ECARX IHU732P"
  ui_print "! Thiet bi hien tai: $DEV"
  abort "! Sai thiet bi, dung cai dat"
fi
ui_print "  thiet bi: $DEV"

# Chi thay khi script tren may dung la ban da doi chieu; ban khac thi dung de khong lam mat thay doi cua no.
if [ ! -f "$TARGET" ]; then
  abort "! Khong co $TARGET, khong can module nay"
fi
CUR=$(sha256sum "$TARGET" | cut -d' ' -f1)
if [ "$CUR" != "$ORIG_SHA256" ]; then
  ui_print "! $TARGET khac ban da doi chieu"
  ui_print "  hien tai: $CUR"
  abort "! Dung lai, can tao lai module tu script moi"
fi
ui_print "  script goc khop sha256"

ui_print " "
ui_print "- Dat permissions_service.sh (PiP = ignore)"
set_perm "$MODPATH/system/bin/permissions_service.sh" 0 2000 0750 u:object_r:system_file:s0

ui_print " "
ui_print "- Xong. Co hieu luc sau khi khoi dong lai."
ui_print " "
